package com.example.springsecurityapplication.enumm;

public enum Status {
     принят, оформлен, ожидает, получен
}
